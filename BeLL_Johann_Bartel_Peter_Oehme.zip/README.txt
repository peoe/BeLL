      Besondere Lernleistung
von Johann Bartel und Peter Oehme

----------------------------------

Diese CD enth�lt das Programm, den
Quelltext, die Dokumentation als
.pdf und Beispieldateien f�r die
Verwendung mit dem Programm.

----------------------------------

Das Programm hat den Dateinamen 
"DXFConverter.jar". Es wurde
unter Java 1.8.0 entwickelt.

ACHTUNG: Zur vollst�ndigen Nutzung
des Programms ist die Anwendung
OpenSCAD notwendig. Diese ist 
kostenlos erh�ltlich unter
http://www.openscad.org/.
Ohne diese Anwendung wird das 
Programm nicht im vollen Umfang
funktionieren.

----------------------------------

Der Ordner "Beispiele" enth�lt
.dxf-Dateien, welche beispielhaft
mit dem Programm verwendet werden
k�nnen.

----------------------------------

Im Ordner "Quelltext" findet sich
der gesamte Quelltext des
Programmes.

----------------------------------

In der Datei "Dokumentation.pdf"
findet sich zus�tzlich noch die 
Dokumentation der Besonderen
Lernleistung.

----------------------------------

  Johann Bartel und Peter Oehme
     Leipzig, der 22.12.2017